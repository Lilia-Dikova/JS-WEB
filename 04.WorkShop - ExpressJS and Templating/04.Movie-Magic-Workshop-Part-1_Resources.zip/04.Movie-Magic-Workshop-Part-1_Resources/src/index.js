const express = require('express');
const app = express();
const port = 3002;

const html = `
<h1>Hello World!</h1>
`;
app.get('/', (req, res) => {
    res.send(html);
});

app.listen(port, console.log(`This app is running on port" ${port}`));
